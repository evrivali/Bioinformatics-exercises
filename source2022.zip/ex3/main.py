import random #εισαγωγή βιβλιοθήκης για την παραγωγή τυχαίων αριθμών
#αρχικοποίηση μετρητών για το σκορ νικών-ήττων παίκτη υπολογιστή
computerwins = 0
playerwins = 0
##
#ο παίκτης και ο υπολογιστής θα πραγματοποιήσουν 100 παιχνίδια. Ο παίκτης θα παίζει με τυχαία στρατηγική ενώ ο υπολογιστής με βέλτιστη. Στο τέλος θα εκτυπώνουμε το σκορ για να αποδείξουμε ότι η στρατηγική του υπολιγστή είναι πράγματα βέλτιση γιατι κερδίζει στο μεγαλύτερο ποσοστό των παιχνιδιών
for i in range (0,100):
    #φτιάχνουμε τα χρωμοσώματα m και n. Έχουμε αποθηκεύσει σε φακέλους το κάθε ένα απο τα δύο χρωμοσώματα. Τα διαβάζουμε και τα αποθηκεύουμε στις αντίστοιχες μεταβλητές.
    temp_m=open(r'gene1.fna','r')
    m= temp_m.read()
    m.replace(" ", "")
    temp_m.close()
    temp_n=open(r'gene2.fna','r')
    n= temp_n.read()
    n.replace(" ", "")
    temp_n.close()
    #
    #ορίζουμε ποιος παίκτης ξεκινά το παιχνίδι. Βάζουμε να ξεκινάει ο παίκτης και όχι ο υπολογιστής (αν και δεν έχει σημασία στο αποτέλεσμα ο παίκτης που θα ξεκινήσει)
    player_turn = True
    flag = False
    while(len(m)>1 or len(n)>1): # ένα παιχνίδι συνεχίζεται μέχρι και τα δύο χρωμοσώματα να έχουν μήκος <=1.
        if (player_turn): #αν ειναι η σειρά του παίκτη τότε οι κινήσεις του είναι τυχαίες και όχι βέλτιστες. Βέβαια υπάρχουν κάποιες κινήσεις που πρέπει να γίνονται
            #για παράδειγμα αν ένα χρωμόσωμα έχει μήκος 1 προφανώς δεν μπορεί να διασπαστεί σε δύο μέρη σύμφωνα με τους κανόνες του παιχνιδιού οπότε θα είναι υποχρεωτικά το χρωμόσωμα που θα πρέπει να καταστραφει.
            if (len(m)<=1):
                choice=0
            elif(len(n)<=1):
                choice=1
            #
            #σε άλλη περίπτωση η επιλογή για το ποιο χρωμόσωμα θα καταστρεφεί και πιο θα διασπαστεί είναι τυχαία
            else:
                choice = random.randint(0, 1)
            if (choice == 0):
                #print(len(n))
                #τυχαίο είναι και το σημείο στο οποίο θα γίνει η διχοτόμιση
                length = random.randint(1, len(n))
                #αφού όλες οι απαραίτητες παράμετροι οριστούν ο παίκτης κάνει την κίνηση του χωρίζοντας το επιλεγμένο χρωμόσωμα σε δυο μέρη με την τρόπο που φαίνεται παρακάτω δημιουργόντας έτσι δυο νεα χρωμοσώματα
                while(len(n[:length])==0 or len(n[length:len(n)])==0):
                    length = random.randint(1, len(n))
                m = n[:length]
                n = n[length:len(n)]
            else:
                #print(len(m))
                length = random.randint(1, len(m))
                while (len(m[:length]) == 0 or len(m[length:len(m)])==0):
                    length = random.randint(1, len(m))
                n = m[:length]
                m = m[length:len(m)]
                ##
            #print("player move")
            #print("m")
            #print(m, len(m))
            #print("n")
            #print(n, len(n))
            player_turn=False
        else:
            #print("computer move")
            #ο υπολογιστής παίζει με τη βέλτιστη στρατηγική. Όταν υπάρχει χρωμόσωμα με ζυγό μήκος ο υπολιγιστής το σπάει σε δύο χρωμοσώματα μονού μήκους καθώς οι μονές ακολουθίες οδηγούν σε ήττα ενώ οι ζυγές οδηγούν σε νίκη
            #ελέγχουμε την περίπτωση που κάποιο χρωμόσωμα έχει ζυγό μήκος
            if (len(m)>0 and len(m)%2==0):
                if (len(m)!=2):
                    length=random.randint(3,len(m))
                    #ελέγχουμε έτσι ώστε η επιλεγμένη θέση που θα διασπαστεί το χρωμόσωμα να δώσει δύο μονές αλληλουχίες
                    while (len(m[:length])%2==0 or len(m[length:len(m)])%2==0 or len(m[:length])==0 or len(m[length:len(m)])==0 ):
                        length=random.randint(3,len(m))
                    n = m[:length]
                    m = m[length:len(m)]
                else:
                    n = m[:1]
                    m = m[1:2]
                #print("m is even i split it into")
                #print("m")
                #print(m, len(m))
                #print("n")
                #print(n, len(n))
            elif(len(n)>0 and len(n)%2==0):
                if (len(n) != 2):
                    length = random.randint(3, len(n))
                    while (len(n[:length]) % 2 == 0 or len(n[length:len(n)]) % 2 == 0 or len(n[:length])==0 or len(n[length:len(n)])==0):
                        length = random.randint(3, len(n))
                    m= n[:length]
                    n = n[length:len(n)]
                else:
                    m = n[:1]
                    n = n[1:2]
                #print("n is even i split it into")
                #print("m")
                #print(m,len(m))
                #print("n")
                #print(n,len(n))
            #στην περίπτωση που κανένα απο τα χρωμοσώματα δεν έχει ζυγό μήκος τότε η επιλογή είναι τυχαία
            else:
                if (len(m) <= 1):
                    choice = 0
                elif (len(n) <= 1):
                    choice = 1
                else:
            #όταν ένα χρωμόσωμα έχει μήκος 3 τότε βέλτιση στρατηγική είναι να είναι αυτό που θα δεν καταστραφεί καθώς αν διασπαστεί είναι βέβαιο ότι θα καταλήξει σε ήττα για τον παίκτη
                    if (len(m) == 3 or len(m)==5):
                        choice = 1
                        #print("i chose m",m)
                        #print(len(m))
                    elif (len(n) == 3 or len(n)==5):
                        choice = 0
                        #print("i chose n", m)
                        #print(len(n))
                    else:
                #σε άλλη περίπτωση η επιλογή είναι τυχαία
                        choice = random.randint(0, 1)
                if (choice==0):
                    length = random.randint(1, len(n))
                #το νέο χρωμόσωμα που θα προκύψει δεν πρέπει να είναι μήκους 0,2 ή 4 καθώς η μια περίπτωση είναι μη αποδεκτή και οι άλλες δύο οδηγούν σε ήττα
                    while (len( n[:length])==2 or len(n[length:len(n)])==2 or len(n[:length])==0 or len(n[length:len(n)])==0 or len( n[:length])==4 or len(n[length:len(n)])==4):
                        if (len(n)==3 or len(n)==5): #Στις περιπτώσεις που ο παίκτης μας έχει αφήσει σε θέση 3 ή 5 η θέση είναι υποχρεωτικά θέση ήττας οπότε βγάνουμε απο την παραπάνω επανάληψη
                            break
                        length = random.randint(1, len(n))
                    m = n[:length]
                    n = n[length:len(n)]
                else:
                    length = random.randint(1, len(m))
                    while (len(m[:length])==2 or len(m[length:len(m)])==2 or len(m[:length])==0 or len(m[length:len(m)])==0):
                        if (len(m)==3):
                            break
                        length = random.randint(1, len(m))
                    n = m[:length]
                    m = m[length:len(m)]
                #print("neither was even i split it into")
                #print("m")
                #print(m, len(m))
                #print("n")
                #print(n, len(n))
            player_turn=True
    #αναλόγως το ποιός παίκτης κέρδισε αυξάνουμε τον αντίστοιχο μετρητή
    # αν το παιχνίδι έχει τελειώσει ελέγχουμε ποιός παίκτης έμεινε χωρίς κίνηση και ενημερώνουμε τους ανίστοιχους μετρητές
    if (player_turn):
        #print("computer wins")
        computerwins += 1
    else:
        #print("player wins")
        playerwins+=1
#εκτυπώνουμε το τελικό σκόρ
print("Itterations where the computer won")
print (computerwins)
print ("Itterations where the player won")
print(playerwins)
#